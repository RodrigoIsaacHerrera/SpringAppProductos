package com.tata.productos.app.SpringAppProductos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAppProductosApplicationTests {

	@Test
	void contextLoads() {
	}

}
