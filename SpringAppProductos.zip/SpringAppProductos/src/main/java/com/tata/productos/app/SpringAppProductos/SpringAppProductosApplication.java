package com.tata.productos.app.SpringAppProductos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAppProductosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAppProductosApplication.class, args);
	}

}
